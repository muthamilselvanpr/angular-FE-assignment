export class UploadFileType {
    'First name' : string;
    'Sur name': string;
    'Issue count': string;
    'Date of birth': string;
}
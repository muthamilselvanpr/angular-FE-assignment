import { Pipe, PipeTransform } from '@angular/core';
import { UploadFileType } from '../app.types';

@Pipe({
  name: 'filterByIssueCount'
})

// To filter issue coun in the data table

export class FilterPipe implements PipeTransform {
  transform(items: UploadFileType[], field: string, value: string): any {
    if (!items || !field) {
      return items;
    }
    return items.filter(item => item['Issue count'] === field);
  }
}


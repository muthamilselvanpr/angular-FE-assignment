import { FilterPipe } from './filter.pipe';

describe('FilterPipe', () => {
  let fp: FilterPipe;

  
  beforeEach(() => {
    fp = new FilterPipe();
  });

  it('filter pipe should be instanciated', () => {
    expect(fp).toBeDefined();
  });

  it('filter pipe should return items if no field is given', () => {
    let items = [];
    items.push({ ['Issue count']: '7' });

    let filtered = fp.transform(items, null, 'Issue count');
    expect(filtered).toEqual(items);
  });

  it('filter pipe should filter', () => {
    let items = [];

    items.push({ ['Issue count']: '1' });
    items.push({ ['Issue count']: '3' });
    items.push({ ['Issue count']: '5' });
    items.push({ ['Issue count']: '7' });

    let filtered = fp.transform(items, '1', 'Issue count');

    expect(filtered.length).toBe(2);
  });
});
import { Component, HostListener } from '@angular/core';
import { UploadFileType } from './app.types';
import * as Papa from 'papaparse';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  
  dataList: UploadFileType[] = [];
  issueCount: string;
  showWarning: boolean = false;
  showContent: boolean = false;
  showBorder: boolean = false;
  scrWidth: any;

  constructor() {
    this.getScreenSize();
  }

  @HostListener('window:resize', ['$event'])
    getScreenSize(event?) {
         this.scrWidth = window.innerWidth;
    }

// parse the .csv file and change to JSON file
  uploadFile(file: File[]) {
    if (file[0]) {
      Papa.parse(file[0], {
        header: true,
        skipEmptyLines: true,
        complete: (result: any) => {
          if (result.meta.fields[2] !== 'Issue count') {
            this.showWarning = true;
            this.showContent = false;
            this.dataList = [];
          } else {
            this.showWarning = false;
            this.showContent = true;
            this.dataList = result.data;
          }
        }
      });
    }
  }
}

# AngularFEAssignMent

##Project Summary

Upload only .csv file, data will visulaize in the screen. we can filter the data by issue count.

##version

version 7.1.1.

##Install

if node module is not in the source code then type `npm install`

##Run File

To view output, type `ng serve`. Navigate to `http://localhost:4200/`.